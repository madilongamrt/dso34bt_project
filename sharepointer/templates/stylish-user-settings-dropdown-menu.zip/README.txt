A Pen created at CodePen.io. You can find this one at http://codepen.io/jakestuts/pen/nEFyw.

 Stylish Custom User Settings Dropdown Menu with CSS

Tutorial from Treehouse Blog: http://blog.teamtreehouse.com/stylish-custom-user-settings-dropdown-menu-with-css